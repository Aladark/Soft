<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../css/chat.css" />
  <title>Document</title>
  <script type="text/javascript">
    function ajax() {

      var req = new XMLHttpRequest();
      red.onreadystatechange = function() {
        if (req.readyState == 4 && req.status == 200) {
          document.getElementById('chat').innerHTML = req.responseText;

        }
      }
      req.open('GET', 'mensagemSQL.php', true);
      req.send();
    }
    setInterval(function() {
      ajax();
    }, 1000);
  </script>
</head>

<body>
  <!--Inicio da header (cabeçalho)-->
  <div class="section">
    <header id="nav" class="sticky-nav">
      <nav class="container">
        <ul role="list" class="nav-grid">
          <li id="w-node-_151d960c-bb04-cfc3-fd7d-356ce1fa0176-31e55b4d" class="list-item-3">
            <!--link junto com a logo-->
            <a href="../index.html" class="nav-logo-link">
              <img src="../img/logo.png" sizes="(max-width: 479px) 80.296875px, 81.65625px" srcset="../img/logo.png 735w" alt="HomePage" class="nav-logo" /></a>
            <!--Fim link junto com a logo-->
          </li>
          <!--link do cadastrar e login-->
          <li class="list-item">
            <a href="#" class="nav-link">Cadastrar</a>
          </li>
          <li class="list-item">
            <a href="../logar/login.php" class="nav-link">Login</a>
          </li>
          <!--Fim link do cadastrar e login-->
        </ul>
      </nav>
    </header>
  </div>
  <!--Fim da header (cabeçalho)-->

  <!--Abaixo está a linha que cria a aba do amigo, no "bloco de amigo selecionado" será descrito exatamente dessa forma
    "<a href="Insira o link" class="list-grou(usuario1)p-item (a classe list-group-item deve estar em qualquer bloco, independente
    se for selecionado ou não) (se quiser deixar o usuario como "selecionado", adicione a propriedade "active" a class
    <img src="link da imagem do usuario" alt"de preferencia, coloque o nick do usuario aqui" <span class="não mexa em
    nada"> agora você coloca o nick do usuario </span></a>"-->

  <!--Se quiser que o usuario indique apareça a borda de notificação, faça que nem com a classe active, adicione a
    classe "notify", lembrando que se o usuario estiver ativo, você vai ter lido a mensagem, logo não precisa da
    notificação-->





  <!--====================AMIGO EXEMPLO===============================================================================-->
  <div class="section">
    <div class="columns">
      <!--Aba de amigos-->
      <div class="col-nick">
        <div class="friend-list">
          <form method=post>
            <?php include_once('../classe/amizadesql.php');

            while ($ra = $SQL->fetch(PDO::FETCH_OBJ)) {
            ?>
              <a value=<?php echo $ra->fk_idamigo ?> onclick="loadDoc()" name='amiguinho' href="" class="list-group-item"><img src="../img/verde.jpg" alt="" />
                <span class="text-distance-icon">Verde</span></a>


            <?php
            }
            if (isset($_POST['amiguinho'])) {
              echo 'meu amigo e corno';
            }




            ?>


          </form>
        </div>
      </div>
      <!--Fim da aba de amigos-->





      <!--========================== CHAT ===============================================================================-->


      <!--Aba de chat-->
      <div class="col-chat">
        <div class="scroll">

          <?php
          $idamigo = 2;
          include_once('../classe/MensagemSQL.php');
          while ($rm = $SQL->fetch(PDO::FETCH_OBJ)) {
            if ($rm->fk_idusuario == 1) { ?>
              <!--Bloco de mensagem do proprio usuario-->
              <div class="contain myuser">
                <!--A classe "right, está deixando o icone na direita, e a mensagem a esquerda"-->
                <img src="../img/among-us-icon-png-02.png" alt="Avatar" class="right" style="width: 100%" />
                <!--Mensagem do proprio usuario-->
                <p><?php echo $rm->mensagem; ?></p>
                <!--Fim da mensagem do proprio usuario-->

                <!--Hora da mensagem-->
                <span class="time-left"><?php echo $rm->hora_mensagem; ?></span>
                <!--Fim da hora da mensagem-->
              </div>
              <!--Fim do bloco de mensagem do proprio usuario-->
            <?php

            } elseif ($rm->fk_idusuarioreceptor == 1) {
            ?>
              <!--Bloco de mensagem de amigo-->
              <div class="contain">
                <img src="../img/verde.jpg" alt="Coloque o nick do usuario aqui" style="width: 100%" />
                <!--Mensagem do usuario-->
                <p><?php echo $rm->mensagem; ?></p>
                <!--Fim da mensagem do usuario-->

                <!--Hora da mensagem-->
                <span class="time-right"><?php echo $rm->hora_mensagem; ?></span>
                <!--Fim da hora da mensagem-->
                <!--Bloco de mensagem de amigo-->

              </div>
        
    <?php }
          } ?>
</div>
    <!--========================== IMPUT MENSAGEM================================================================================-->
    <!--Input de texto, para o usuario inserir a mensagem-->
    <div class="chat-input" contenteditable="" style="margin-top: 15px"></div>
    <!--Fim do Input de texto, para o usuario inserir a mensagem-->

    <!--Fim da aba de chat-->
      </div>
    </div>


    </script>
</body>

</html>