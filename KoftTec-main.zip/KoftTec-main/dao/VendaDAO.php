<?php

// Venda.
class VendaDAO{

private $IdVenda = null;
private $Data_Venda = null;
private $Fk_IdUsuario = null;
private $Fk_IdForma_Pagamento = null;
private $Fk_Item = null;


// Get the value of IdVenda.

public function getIdVenda()
{
return $this->IdVenda;
}


// Set the value of IdVenda.

public function setIdVenda($IdVenda): self
{
$this->IdVenda = $IdVenda;

return $this;
}


// Get the value of Data_Venda.

public function getDataVenda()
{
return $this->Data_Venda;
}


// Set the value of Data_Venda.

public function setDataVenda($Data_Venda): self
{
$this->Data_Venda = $Data_Venda;

return $this;
}


// Get the value of Fk_IdUsuario.

public function getFkIdUsuario()
{
return $this->Fk_IdUsuario;
}


// Set the value of Fk_IdUsuario.

public function setFkIdUsuario($Fk_IdUsuario): self
{
$this->Fk_IdUsuario = $Fk_IdUsuario;

return $this;
}


// Get the value of Fk_IdForma_Pagamento.

public function getFkIdFormaPagamento()
{
return $this->Fk_IdForma_Pagamento;
}


// Set the value of Fk_IdForma_Pagamento.

public function setFkIdFormaPagamento($Fk_IdForma_Pagamento): self
{
$this->Fk_IdForma_Pagamento = $Fk_IdForma_Pagamento;

return $this;
}


// Get the value of Fk_Item.

public function getFkItem()
{
return $this->Fk_Item;
}

// Set the value of Fk_Item.

public function setFkItem($Fk_Item): self
{
$this->Fk_Item = $Fk_Item;

return $this;
}
}






?>