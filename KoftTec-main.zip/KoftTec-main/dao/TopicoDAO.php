<?php
// Topico
class TopicoDAO{
 
 
    private $Descricao = null;
    private $IdTopico = null;
    private $Data_Topico = null;
    private $Fk_IdUsuario = null;


    // Get the value of Descricao.
    public function getDescricao()
    {
        return $this->Descricao;
    }

    // Set the value of Descricao.
    public function setDescricao($Descricao)
    {
        $this->Descricao = $Descricao;

        return $this;
    }
   
    // Get the value of IdTopico.
    public function getIdTopico()
    {
        return $this->IdTopico;
    }

    // Set the value of IdTopico.
    public function setIdTopico($IdTopico)
    {
        $this->IdTopico = $IdTopico;

        return $this;
    }

    // Get the value of Data_Topico.
    public function getDataTopico()
    {
        return $this->Data_Topico;
    }

    // Set the value of Data_Topico.
    public function setDataTopico($Data_Topico)
    {
        $this->Data_Topico = $Data_Topico;

        return $this;
    }

    // Get the value of Fk_IdUsuario.
    public function getFkIdUsuario()
    {
        return $this->Fk_IdUsuario;
    }

    // Set the value of Fk_IdUsuario.
    public function setFkIdUsuario($Fk_IdUsuario)
    {
        $this->Fk_IdUsuario = $Fk_IdUsuario;

        return $this;
    }

    
}
?>