<?php
// Venda Usuario.
class VendaUsuario{
 private $Venda_Usuario = null;
 private $Fk_Usuario_Comprador = null;
 private $Fk_IdForma_Pagamento = null;
 private $Fk_IdItem_Usuario = null;
 private $Data_Compra = null;




 
// Get the value of Venda_Usuario.

 public function getVendaUsuario()
 {
  return $this->Venda_Usuario;
 }

 
// Set the value of Venda_Usuario.

 public function setVendaUsuario($Venda_Usuario): self
 {
  $this->Venda_Usuario = $Venda_Usuario;

  return $this;
 }

 
// Get the value of Fk_Usuario_Comprador.

 public function getFkUsuarioComprador()
 {
  return $this->Fk_Usuario_Comprador;
 }

 
// Set the value of Fk_Usuario_Comprador.

 public function setFkUsuarioComprador($Fk_Usuario_Comprador): self
 {
  $this->Fk_Usuario_Comprador = $Fk_Usuario_Comprador;

  return $this;
 }

 
// Get the value of Fk_IdForma_Pagamento.

 public function getFkIdFormaPagamento()
 {
  return $this->Fk_IdForma_Pagamento;
 }

 
// Set the value of Fk_IdForma_Pagamento.

 public function setFkIdFormaPagamento($Fk_IdForma_Pagamento): self
 {
  $this->Fk_IdForma_Pagamento = $Fk_IdForma_Pagamento;

  return $this;
 }

 
// Get the value of Fk_IdItem_Usuario.

 public function getFkIdItemUsuario()
 {
  return $this->Fk_IdItem_Usuario;
 }

 
// Set the value of Fk_IdItem_Usuario.

 public function setFkIdItemUsuario($Fk_IdItem_Usuario): self
 {
  $this->Fk_IdItem_Usuario = $Fk_IdItem_Usuario;

  return $this;
 }

 
// Get the value of Data_Compra.

 public function getDataCompra()
 {
  return $this->Data_Compra;
 }

 
// Set the value of Data_Compra.

 public function setDataCompra($Data_Compra): self
 {
  $this->Data_Compra = $Data_Compra;

  return $this;
 }
}





?>