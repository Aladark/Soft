<?php
// TipoItem
 class TipoItemDAO{
     
private $Id_Tipo_Item = null;
private $Desc_Tipo_Item = null;



// Get the value of Id_Tipo_Item.
public function getIdTipoItem()
{
return $this->Id_Tipo_Item;
}
// Set the value of Id_Tipo_Item.
public function setIdTipoItem($Id_Tipo_Item)
{
$this->Id_Tipo_Item = $Id_Tipo_Item;

return $this;
}

// Get the value of Desc_Tipo_Item.
public function getDescTipoItem()
{
return $this->Desc_Tipo_Item;
}
// Set the value of Desc_Tipo_Item.
public function setDescTipoItem($Desc_Tipo_Item)
{
$this->Desc_Tipo_Item = $Desc_Tipo_Item;

return $this;
}

}

?>