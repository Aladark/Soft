<?php
// Usuario.
class UsuariosDAO{
	private $IdUsuario = null;
	private $Login = null;
	private $Senha = null;
	private $Nome = null;
	private $Email = null;
	private $Data_Nascimento = null;
	private $Level = null;
	private $Sexo = null;
	private $Fk_IdTipo_Conta = null;
	private $Foto = null;
	private $Moeda = null;
   

   // Get the value of IdUsuario.
	   public function GetIdUsuario(){
		   return $this->IdUsuario;
	   }
	   
	   // Set the value of IdUsuario.
	   public function SetIdUsuario($idusuario){
		   $this->IdUsuario = $idusuario;
	   }
	   
   // Get the value of Login.
		public function GetLogin(){
		   return $this->Login;
	   }
	   
	   // Set the value of Login.
	   public function SetLogin($login){
		   $this->Login = $login;
	   }
	   
   // Get the value of Senha.
	   public function GetSenha(){
		   return $this->Senha;
	   }
	   
	   // Set the value of Senha.
	   public function SetSenha($senha){
		   $this->Senha = $senha;
	   }
	   
   // Get the value of Nome. 
		public function GetNome(){
		   return $this->Nome;
	   }
	   
	   // Set the value of Nome.
	   public function SetNome($nome){
		   $this->Nome = $nome;
	   }
	   
   // Get the value of Email. 
   public function GetEmail(){
	   return $this->Email;
   }
   
   // Set the value of Email.
   public function SetEmail($email){
	   $this->Email = $email;
   }
   
   // Get the value of Data_Nascimento.
 public function GetData_Nascimento(){
	   return $this->Data_Nascimento;
   }
   
   // Set the value of Data_Nascimento.
   public function SetData_Nascimento($data_nascimento){
		$this->Data_Nascimento = $data_nascimento;
   }
   
   // Get the value of Level. 
   public function GetLevel(){
	   return $this->Level;
   }
   
   // Set the value of Level.
   public function SetLevel($level){
		$this->Level = $level;
   }  
   
   // Get the value of Sexo.
   public function GetSexo(){
	   return $this->Sexo;
   }
   
   // Set the value of Sexo.
   public function SetSexo($sexo){
	   $this->Sexo = $sexo;
   }
   
   // Get the value of Fk_IdTipo_Conta.
   public function GetFk_IdTipo_Conta(){
	   return $this->Fk_IdTipo_Conta;
   }
   // Set the value of Fk_IdTipo_Conta.
   public function SetFk_IdTipo_Conta($fk_idtipo_conta){
	   $this->Fk_IdTipo_Conta = $fk_idtipo_conta;
   }
   
   // Get the value of Foto.
    public function GetFoto(){
	   return $this->Foto;
   }
   
   // Set the value of Foto.
   public function SetFoto($foto){
	   $this->Foto = $foto;
   }
   
   // Get the value of Moeda.
   public function GetMoeda(){
	   return $this->Moeda;
   }
   
   // Set the value of Moeda.
   public function SetMoeda($moeda){
	   $this->Moeda = $moeda;
   }
}
?>