<?php
// PlataformaJogo
class PlataformaJogoDAO{

 private $Fk_IdJogo = null;
 private $Fk_IdPlataforma = null;




 
// Get the value of Fk_IdJogo.

 public function getFkIdJogo()
 {
  return $this->Fk_IdJogo;
 }

 
// Set the value of Fk_IdJogo.

 public function setFkIdJogo($Fk_IdJogo): self
 {
  $this->Fk_IdJogo = $Fk_IdJogo;

  return $this;
 }

 
// Get the value of Fk_IdPlataforma.

 public function getFkIdPlataforma()
 {
  return $this->Fk_IdPlataforma;
 }

 
// Set the value of Fk_IdPlataforma.

 public function setFkIdPlataforma($Fk_IdPlataforma): self
 {
  $this->Fk_IdPlataforma = $Fk_IdPlataforma;

  return $this;
 }
}
?>

