<?php
// TipoConta.
class TipoConta{
	
   private $IdTipo_Conta = null;
   private $Desc_Tipo = null;
   private $Nivel = null;

	// Get the value of IdTipo_Conta.
	   public function GetIdTipo_Conta(){
		   return $this->IdTipo_Conta;
	   }
	   // Set the value of IdTipo_Conta.
	   public function SetIdTipo_Conta($idtipo_conta){
		   $this->IdTipo_Conta = $idtipo_conta;
	   }
	// Get the value of Desc_Tipo.
	 public function GetDesc_Tipo(){
		   return $this->IdDesc_Tipo;
	   }
	   // Set the value of Desc_Tipo.
	   public function SetDesc_Tipo($desc_tipo){
		   $this->Desc_Tipo = $desc_tipo;
	   }
    // Get the value of Nivel.
	 public function GetNivel(){
		   return $this->IdTipo_Conta;
	   }
	   // Set the value of Nivel.
	   public function SetNivel($nivel){
		   $this->Nivel = $nivel;
	   }
	}
?>