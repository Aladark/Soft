<?php
// Plataforma.
class PlataformaDAO{

 private $IdPlataforma = null;
 private $Desc_Platafoma = null;



 
// Get the value of IdPlataforma.

 public function getIdPlataforma()
 {
  return $this->IdPlataforma;
 }

 
// Set the value of IdPlataforma.

 public function setIdPlataforma($IdPlataforma): self
 {
  $this->IdPlataforma = $IdPlataforma;

  return $this;
 }

 
// Get the value of Desc_Platafoma.

 public function getDescPlatafoma()
 {
  return $this->Desc_Platafoma;
 }

 
// Set the value of Desc_Platafoma.

 public function setDescPlatafoma($Desc_Platafoma): self
 {
  $this->Desc_Platafoma = $Desc_Platafoma;

  return $this;
 }
}

?>