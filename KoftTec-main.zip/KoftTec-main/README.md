# KoftTec
TCC da KoftTec
usuarios mais reportados em X jogos
jogos com maiores indices de reports

jogos com maiores indices de elogios
usuarios com maiores indices de elogios em X jogos

categoria de produtos mais vendidos
usuarios que mais vendem na plataforma

relatorio do "ponto" dos moderadores

indice de usuarios toxicos baseado nos usuarios totais
indice de usuarios amigaveis baseado nos usuarios totais

Lista de coisas que necessitam de modificação ou serem adicionadas:

//Botão de enviar mensagem na tela chat
//Mudar cor e disposição do Scroll da mensagem na tela chat
//Arrumar a animação para adicionar a NavBar
//Criar uma fonte com as letras criadas
//Tentar adicionar a função de Crop de imagem na tela cadastrar

https://www.canva.com/design/DAFFvnMkm6c/kJd2dGEdjc-XxkvYmeby5g/edit


cadastrar user
adicionar adm
adicionar plataforma
adicionar genero
adicionar jogo
escolher jogo
adicionar grupo //////////////
entrar no grupo
mandar mensagem no grupo
criar topico //////////////////
mandar mensagem no topico
visualizar jogos no perfil 

