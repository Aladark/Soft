<?php
error_reporting(0);
  include_once("topo.php");
  include_once("controle.php");

?>