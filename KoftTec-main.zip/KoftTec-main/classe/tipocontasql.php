<?php
include_once("funcoes_sql.php");
include_once("conexao.php");
include_once("../DAO/TipoContaDAO.php")

// Tipo_Conta.
class TipoContaSQL{
	
	
	public $conexao;
	public $Tipo_Conta;

	// metodo construdor. 
	function TipoContaSQL{
		$conexao = new conexao();
		$Tipo_Conta = new TipoContaDAO();
	}
	
	if (isset($_POST["act"]) && $_POST["act"] == "save" && $empresa != "") {
		try {
	
	function inserirTipoConta{
		
	}
	
	







}

?>